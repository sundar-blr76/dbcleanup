#!/bin/bash

# Stop the containers
echo "Stopping the containers..."
docker-compose down

echo "Containers stopped successfully!" 